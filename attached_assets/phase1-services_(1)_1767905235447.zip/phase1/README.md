# Phase 1: Services Layer - Deployment Guide

## What Changed

We extracted all database operations into a services layer. This:
- Reduces App.js by ~135 lines
- Centralizes all Supabase calls in one place
- Makes debugging data issues much easier
- Sets up the pattern for future refactors

## Files

```
src/
├── App.js          (3,929 lines - down from 4,064)
└── services/
    └── index.js    (323 lines - new file)
```

## Deployment Steps

### 1. Create the services folder
```bash
cd ~/projects/sub3-vt-deploy
mkdir -p src/services
```

### 2. Copy the files
```bash
# Copy services file
cp ~/Downloads/phase1/services.js src/services/index.js

# Replace App.js
cp ~/Downloads/phase1/App.js src/App.js
```

### 3. Deploy
```bash
vercel --prod
```

## What to Test

After deploying, verify:
- [ ] Settings save and load correctly
- [ ] Calendar data persists
- [ ] Strava connects/disconnects properly
- [ ] All existing functionality works

## Rollback

If something breaks:
```bash
# Restore from backup
cp src/App.js.backup src/App.js
rm -rf src/services
vercel --prod
```

## Next Phase

Phase 2 will extract utility functions (date helpers, pace calculations, workout colors) into a `src/utils/` folder. This will further reduce App.js and make the code more reusable.
